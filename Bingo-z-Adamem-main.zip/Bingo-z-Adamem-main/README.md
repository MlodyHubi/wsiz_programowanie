# Bingo-z-Adamem
Bingo dla Adam_Grabowiecki (wulgarne słowa na potrzebe streamera)
404ptk.github.io/Bingo-z-Adamem/
